<?php 
	include('conn.php');
	session_start();
	if(isset($_POST['username'])){
		$username=$_POST['username'];
		$password=md5($_POST['password']);

		$ip = $_SERVER['REMOTE_ADDR'];
		$captcha = $_POST['g-recaptcha-response']; 
		$secretkey = "6LfZ_9IlAAAAAHn5zA_n1SA4nWnIaVVYWAvbo56z";
        $respuesta = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretkey&response=$captcha&remoteip=$ip");
		$atributos = json_decode($respuesta, TRUE);
		

		$query=$conn->query("select * from user where username='$username' and password='$password'");

		if ($query->num_rows>0){
			$row=$query->fetch_array();
			$_SESSION['user']=$row['userid']; 
		}
		
		else{
			?>
  				<span>Inicio de sesión fallido. Usuario no encontrado..</span>
  			<?php 
		}
		if(!$atributos['success']){
			?>
  				<span>Verificar captcha.</span>
  			<?php 

		}

	}
?>