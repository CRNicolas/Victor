<?php
	include('conn.php');
	if(isset($_POST['susername'])){
		$username=$_POST['susername'];
		$password=$_POST['spassword'];


		$ip = $_SERVER['REMOTE_ADDR'];
		$captcha = $_POST['g-recaptcha-response']; 
		$secretkey = "6LfZ_9IlAAAAAHn5zA_n1SA4nWnIaVVYWAvbo56z";
        $respuesta = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretkey&response=$captcha&remoteip=$ip");
		$atributos = json_decode($respuesta, TRUE);
		
		$query=$conn->query("select * from user where username='$username'");

		if ($query->num_rows>0){
			?>
  				<span>Nombre de usuario ya existe.</span>
  			<?php 
		}

		elseif (!preg_match("/^[a-zA-Z0-9_]*$/",$username)){
			?>
  				<span style="font-size:11px;">Nombre de usuario no válido. No se permiten espacios ni caracteres especiales. </span>
  			<?php 
		}
		elseif (!preg_match("/^[a-zA-Z0-9_]*$/",$password)){
			?>
  				<span style="font-size:11px;">Contraseña no válida. No se permiten espacios ni caracteres especiales..</span>
  			<?php 
		}
		if(!$atributos['success']){
			?>
  				<span>Verificar captcha.</span>
  			<?php 

		}

		else{
			$mpassword=md5($password);
			$conn->query("insert into user (username, password) values ('$username', '$mpassword')");
			?>
  				<span>Registro exitoso..</span>
  			<?php 
		}
	}
?>